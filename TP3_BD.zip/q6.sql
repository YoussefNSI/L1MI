   nomp   
----------
 briques
 tuiles
 parpaing
(3 lignes)

