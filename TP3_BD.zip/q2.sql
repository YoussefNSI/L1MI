   nomf    | prix |  nomp   
-----------+------+---------
 DAMASCO   | 1150 | tuiles
 PREBLOCS  | 1200 | tuiles
 SAMACO    |  900 | ciment
 ABOUNAYAN | 1500 | briques
 DAMASCO   | 1500 | briques
 SAMACO    | 1450 | briques
(6 lignes)

