  nomp   | prix 
---------+------
 briques | 1500
 tuiles  | 1150
(2 lignes)

