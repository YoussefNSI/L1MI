   nomf    | prix |  nomp   
-----------+------+---------
 ABOUNAYAN | 1500 | briques
 SAMACO    | 1450 | briques
 DAMASCO   | 1500 | briques
 SAMACO    |  900 | ciment
 PREBLOCS  | 1200 | tuiles
 DAMASCO   | 1150 | tuiles
(6 lignes)

