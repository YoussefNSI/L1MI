   nomp   
----------
 briques
 parpaing
 briques
(3 lignes)

