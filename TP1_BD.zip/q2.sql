   nomf    |       villef        
-----------+---------------------
 ABOUNAYAN | 92190 Meudon
 CIMA      | 44150 NANTES
 PREBLOCS  | 92230 GENNEVILLIERS
 SAMACO    | 75116 PARIS
 DAMASCO   | 49100 ANGERS
(5 lignes)

