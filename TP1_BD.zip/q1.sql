  numf   |   nomp   | prix 
---------+----------+------
 FOUR001 | sable    |  300
 FOUR001 | briques  | 1500
 FOUR001 | parpaing | 1150
 FOUR003 | tuiles   | 1200
 FOUR003 | parpaing | 1300
 FOUR004 | parpaing | 1350
 FOUR004 | ciment   |  900
 FOUR004 | briques  | 1450
 FOUR002 | sable    |  350
 FOUR005 | briques  | 1500
 FOUR005 | tuiles   | 1150
(11 lignes)

