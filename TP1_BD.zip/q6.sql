 nomc |   villec    
------+-------------
 Jean | 75006 Paris
(1 ligne)

