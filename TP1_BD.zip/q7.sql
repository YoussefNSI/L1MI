   nomp   | prix 
----------+------
 sable    |  300
 sable    |  350
 ciment   |  900
 tuiles   | 1150
 parpaing | 1150
 tuiles   | 1200
 parpaing | 1300
 parpaing | 1350
 briques  | 1450
 briques  | 1500
(10 lignes)

