  numf   
---------
 FOUR001
 FOUR001
 FOUR003
 FOUR004
 FOUR004
 FOUR005
(6 lignes)

