   nomp   
----------
 parpaing
 ciment
 briques
(3 lignes)

