  nomc  |      villec      
--------+------------------
 Paul   | 75003 Paris
 Pierre | 92400 Courbevoie
(2 lignes)

