   nomp   
----------
 briques
 parpaing
 briques
 briques
(4 lignes)

