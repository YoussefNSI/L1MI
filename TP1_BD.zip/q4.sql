   nomp   
----------
 parpaing
 briques
(2 lignes)

